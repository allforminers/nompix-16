A place for logs and such
