For alerts related to payouts and such
